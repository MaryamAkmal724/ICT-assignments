<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f2f2; /* light background color */
            text-align: center;
        }

        header {
            background: #333;
            color: white;
            padding: 20px;
            font-size: 28px;
        }

        nav {
            background: #444;
            padding: 10px;
        }

        nav a {
            color: white;
            margin: 15px;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            margin-top: 50px;
        }

        .box {
            display: inline-block;
            padding: 25px;
            background: white;
            border-radius: 10px;
            width: 50%;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>

<header>
    My Website
</header>

<nav>
    <a href="signup.php">Signup</a>
    <a href="login.php">Login</a>
</nav>

<div class="container">
    <div class="box">
        <h2>Welcome to My Website</h2>
        <p>This is a simple landing page for our PHP login system project.</p>
        <p>Use the navigation links above to create an account or login.</p>
    </div>
</div>

</body>
</html>