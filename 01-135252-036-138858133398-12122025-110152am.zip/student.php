<?php
session_start(); // start session to read user info
// check if user is logged in
if (!$_SESSION["user"]) {
header("Location: login.php"); // redirect if not logged in
exit;
}
$name = $_SESSION["user"]["name"]; // get student name from session
?>
<h1>Student Dashboard</h1>
<p>Welcome <?php echo $name; ?></p>
<a href="logout.php">Logout</a>