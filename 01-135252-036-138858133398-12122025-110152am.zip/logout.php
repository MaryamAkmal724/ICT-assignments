<?php
session_start(); // start session to access data
session_destroy(); // remove all session data and logout user
header("Location: login.php"); // redirect back to login page
?>