<?php
// connect to MySQL server using root user and the database login_system
$db = new mysqli("localhost", "root", "", "login_system");
// check if the connection failed
if ($db->connect_error) {
die("Connection failed");
}
?>