<?php
include "db.php"; // include database connection file
if ($_SERVER["REQUEST_METHOD"] == "POST") { // check if the form was submitted
$name = trim($_POST['name']); // get name from form
$email = trim($_POST['email']); // get email from form
$pass = trim($_POST['password']); // get password from form
// trim() function removes any extra spaces before or after the input
$role = "student"; // default role for new users
if (empty($name) || empty($email) || empty($pass)) {
die("Error: All fields are required.");
} // validate inputs
$check = $db->query("SELECT * FROM users WHERE email = '$email'");
$found = $check->fetch_assoc(); // check if this email already exists in the database
if ($found) { // if user exists, show message
echo "This email already exists";
} else { // if new email, insert data
$db->query("INSERT INTO users(name,email,password,role) VALUES ('$name','$email','$pass','$role')");
echo "Signup successful";
}
}
?>
<!-- signup form -->
<form name="signupForm" method="post">
Name
<input type="text" name="name" required><br><br>
Email
<input type="email" name="email" required><br><br>
Password
<input type="password" name="password" required><br><br>
<button type="submit">Signup</button>
</form>
<!-- link to login page -->
<p>Already have an account</p>
<a href="login.php">
<button>Login</button>
</a>
