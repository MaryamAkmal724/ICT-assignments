<?php
session_start(); // start session to read user data
// check if user is logged in
if (!$_SESSION["user"]) {
header("Location: login.php"); // redirect if not logged in
exit;
}
// check if logged in user is admin
if ($_SESSION["user"]["role"] != "admin") {
echo "Access denied"; // block access for non admins
exit;
}
$name = $_SESSION["user"]["name"]; // get admin name from session
?>
<h1>Admin Dashboard</h1>
<p>Welcome <?php echo $name; ?></p>
<a href="logout.php">Logout</a>