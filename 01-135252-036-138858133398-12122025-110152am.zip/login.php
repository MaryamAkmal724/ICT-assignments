<?php
include "db.php"; // include database connection
session_start(); // start session to store user info after login
if ($_SERVER["REQUEST_METHOD"] == "POST") { // check if form is submitted
$email = $_POST["email"]; // get email
$pass = $_POST["password"]; // get password
// check if user with this email and password exists
$result = $db->query("SELECT * FROM users WHERE email = '$email' AND password = '$pass'");
$user = $result->fetch_assoc();
if ($user) { // if user found
$_SESSION["user"] = $user; // store user information in session
// check role and redirect accordingly. header("Location: "); is for destination
if ($user["role"] == "admin") {
header("Location: admin.php");
exit;
}
if ($user["role"] == "student") {
header("Location: student.php");
exit;
}
} else {
echo "Incorrect email or password"; // login failed
}
}
?>
<!-- login form -->
<form method="post">
Email
<input type="email" name="email" require><br><br>
Password
<input type="password" name="password" require><br><br>
<button type="submit">Login</button>
</form>
<!-- link to signup page -->
<p>Do not have an account</p>
<a href="signup.php">
<button>Signup</button>
</a>