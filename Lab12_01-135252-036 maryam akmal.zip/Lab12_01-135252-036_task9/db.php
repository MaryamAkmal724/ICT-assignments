<?php
$conn = mysqli_connect("localhost", "root", "", "StudentManagement");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "DB Connected Successfully!";
?>
