<?php
include "db.php";

$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$department = $_POST['department'];

$query = "INSERT INTO students(name, email, age, department) VALUES('$name', '$email', '$age', '$department')";

if(mysqli_query($conn, $query)) {
    echo "<p style='text-align:center; color:green;'>Student added successfully!</p>";
    echo "<p style='text-align:center;'><a href='index.html'>Add Another Student</a> | <a href='display.php'>View Students</a></p>";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
