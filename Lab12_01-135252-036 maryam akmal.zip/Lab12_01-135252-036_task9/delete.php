<?php
include "db.php";

$id = $_GET['id'];

$query = "DELETE FROM students WHERE id=$id";

if(mysqli_query($conn, $query)){
    echo "<p style='text-align:center; color:red;'>Student with ID $id deleted successfully!</p>";
    echo "<p style='text-align:center;'><a href='display.php'>Back to Students List</a></p>";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
