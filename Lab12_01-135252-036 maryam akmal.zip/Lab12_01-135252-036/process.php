<?php
$user = $_POST['username'];
$email = $_POST['email'];

echo "<h1>Form Submission</h1>";
echo "<p>Name: $user</p>";
echo "<p>Email: $email</p>";
?>
