<?php
$name = "Maryam Akmal";   
$course = "BSIT";         
echo "<h1>Welcome, $name!</h1>";
echo "<p>Course: $course</p>";
?>
