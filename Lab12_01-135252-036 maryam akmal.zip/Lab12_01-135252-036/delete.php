<?php
include "db.php"; 
error_reporting(E_ALL);
ini_set('display_errors', 1);


$id = $_POST['id'];

$query = "DELETE FROM users WHERE id=$id";

if(mysqli_query($conn, $query)) {
    echo "Record with ID $id deleted successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
