<?php
include "db.php";  

$name  = $_POST['name'];
$email = $_POST['email'];
$age   = $_POST['age'];

$query = "INSERT INTO users(name, email, age) VALUES('$name', '$email', '$age')";

if(mysqli_query($conn, $query)) {
    echo "Hello Maryam Akmal, your data has been stored!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
